import java.rmi.*;
public interface Hello extends Remote {
    public String ditBonjour() throws java.rmi.RemoteException;
}