<?php
define("SITE_ROOT", "http://localhost/PROJETWEB/");
define("SEPARATOR", DIRECTORY_SEPARATOR);
define("DB_DSN", "mysql:host=localhost;dbname=projetweb");
define("DB_USER", "root");
define("DB_PASSWORD", "");
?>