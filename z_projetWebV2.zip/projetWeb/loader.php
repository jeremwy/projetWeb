<?php
//ici se trouvent tous les fichiers qu'il faut inclure
require_once("config.php");
require_once("Vendor/util.php");
require_once("Controller/Controller.php");
require_once("View/View.php");
require_once("View/RedirectView.php");
require_once("Model/Class/User.php");
?>