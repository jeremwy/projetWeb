<h1><?php echo $dReponse["title"]; ?></h1>
<p><?php echo $dReponse["message"]; ?></p>