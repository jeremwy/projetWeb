<h1>Bienvenue</h1>
<p><a href="<?php echo SITE_ROOT; ?>jouer" class="jouerLink">JOUER</a></p>